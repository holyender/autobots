<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <title>AUTOMATION TEST REPORT SYSTEM</title>
   <link rel="stylesheet" href="./css/login.css">
</head>
<body>
<div id="page" class="container">
      <header class="header-region" role="banner">
         <div id="logo"><img src="./image/logo.png" alt="Home" title="Home"></div>
         <h2 id="header_title">AUTOMATION TEST REPORT SYSTEM</h2>
         <div class="demo-info" style="margin-bottom:10px">
            <div class="demo-tip icon-tip">&nbsp;</div>
            <div></div>
         </div>
      </header>
      <content class="content-region" role="banner">
         <div class="panel-cus" title="Login">
            <form method="post">
               <table cellpadding="5">
                  <tr>
                      <td><label>Username:</label></td>
                      <td><input type="text" name="user" id="user" /></td>
                  </tr>
                  <tr>
                      <td><label>Password:</label></td>
                      <td><input type="password" name="password" id="keypass" /></td>
                  </tr>
                  <tr>
                     <!--<td><a class="btn" href="http://10.0.61.146/CafeAttendance_simple2/reset_pwd.php">Set Password</a></td>-->
                     <td></td>
                     <td><input type="submit" class="button" id="submit" name="Submit" value="Submit" /></td>
                  </tr>
               </table>
            
            </form>
         </div>
      </content>
   </div>
   </body>
</html>